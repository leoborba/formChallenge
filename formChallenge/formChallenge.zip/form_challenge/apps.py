from django.apps import AppConfig


class FormChallengeConfig(AppConfig):
    name = 'form_challenge'
