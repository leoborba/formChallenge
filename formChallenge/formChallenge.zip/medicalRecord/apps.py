from django.apps import AppConfig


class MedicalrecordConfig(AppConfig):
    name = 'medicalRecord'
